"""
Nepali Devanagari OCR Pipeline -- built around the fixed template
`Red_Minimalist_Membership_Form_A4.pdf`.

STAGE OVERVIEW
--------------
1. Reference setup : rasterize the clean template PDF once, at RENDER_DPI,
                      to serve as the alignment reference and the source of
                      truth for pixel-space field coordinates.
2. Preprocess       : load an incoming scan, convert to grayscale, deskew.
3. Align            : register the scan against the reference render
                      (ORB features + homography), so template_config's
                      fixed coordinates line up regardless of scan
                      skew/shift/scale.
4. Crop ROIs        : slice out each field's ZONE OF INTEREST -- a tight,
                      left-anchored sub-region of the drawn input box, not
                      the full oversized box (see template_config.py for
                      why this matters).
5. OCR              : run the CRNN+CTC model on each cropped ROI.
6. Assemble         : return {field_name: recognized_text} as a dict/JSON.

USAGE
-----
    from ocr_pipeline import OCRPipeline

    pipeline = OCRPipeline(
        model_path="models/p2_epoch19_acc49.1.pth",
        char_list_path="models/char_list.txt",
    )
    result = pipeline.run("path/to/scanned_form.jpg")
    print(result)   # {"first_name": "राम", "last_name": "शर्मा", ...}

WHAT'S REAL VS. WHAT YOU STILL NEED TO PLUG IN
------------------------------------------------
REAL (extracted directly from your actual PDF, not guessed):
  - All 9 field box coordinates (template_config.py)
  - ROI (zone-of-interest) cropping logic, addressing the oversized-box issue
  - Alignment, preprocessing, CTC decode, CLI, JSON output

STILL PLACEHOLDER (must come from your training notebooks):
  - `CRNN` architecture -- must match what p2_epoch19_acc49.1.pth was
    trained with, or state_dict loading will fail.
  - Character list file -- exact charset + order used during training.
  - No real filled-sample testing has been done -- validate against actual
    filled scans once available.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from pathlib import Path

import cv2
import fitz  # PyMuPDF, for rendering the reference PDF
import numpy as np
import torch
import torch.nn as nn

import template_config as cfg

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger("ocr_pipeline")


# --------------------------------------------------------------------------
# Reference template setup
# --------------------------------------------------------------------------

def render_reference_template(pdf_path: str, dpi: int = cfg.RENDER_DPI) -> np.ndarray:
    """Rasterize page 1 of the clean template PDF to a grayscale image at
    the given DPI. This becomes the alignment target and defines pixel
    space for all field coordinates.
    """
    doc = fitz.open(pdf_path)
    page = doc[0]
    pix = page.get_pixmap(dpi=dpi)

    img = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.height, pix.width, pix.n)
    if pix.n >= 3:
        gray = cv2.cvtColor(img[:, :, :3], cv2.COLOR_RGB2GRAY)
    else:
        gray = img[:, :, 0]
    return gray


# --------------------------------------------------------------------------
# Stage: Preprocessing (incoming scans)
# --------------------------------------------------------------------------

def load_and_preprocess(image_path: str) -> np.ndarray:
    """Load a scanned/filled document image and apply basic cleanup:
    grayscale + deskew. Returns a single-channel image.
    """
    image = cv2.imread(str(image_path))
    if image is None:
        raise FileNotFoundError(f"Could not read image: {image_path}")

    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    return _deskew(gray)


def _deskew(gray: np.ndarray) -> np.ndarray:
    """Correct small rotation using minAreaRect of thresholded foreground
    pixels. Handles scanner-induced skew; larger shifts/perspective are
    handled separately by the homography alignment step.
    """
    thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]
    coords = np.column_stack(np.where(thresh > 0))
    if coords.size == 0:
        return gray

    angle = cv2.minAreaRect(coords)[-1]
    angle = -(90 + angle) if angle < -45 else -angle

    if abs(angle) < 0.3:
        return gray

    (h, w) = gray.shape[:2]
    rot_matrix = cv2.getRotationMatrix2D((w // 2, h // 2), angle, 1.0)
    return cv2.warpAffine(
        gray, rot_matrix, (w, h),
        flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE,
    )


# --------------------------------------------------------------------------
# Stage: Alignment to reference template
# --------------------------------------------------------------------------

def align_to_template(scan_gray: np.ndarray, reference_gray: np.ndarray) -> np.ndarray:
    """Warp `scan_gray` to match `reference_gray`'s layout via ORB keypoint
    matching + homography, so fixed ROI coordinates remain valid.
    """
    orb = cv2.ORB_create(nfeatures=3000)
    kp1, des1 = orb.detectAndCompute(scan_gray, None)
    kp2, des2 = orb.detectAndCompute(reference_gray, None)

    if des1 is None or des2 is None:
        raise RuntimeError(
            "Could not find enough features to align scan to template. "
            "Check image quality / contrast."
        )

    matcher = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
    matches = sorted(matcher.match(des1, des2), key=lambda m: m.distance)

    num_good = max(int(len(matches) * 0.15), 10)
    good_matches = matches[:num_good]
    if len(good_matches) < 4:
        raise RuntimeError(
            "Too few reliable matches between scan and reference template "
            "to compute alignment."
        )

    src_pts = np.float32([kp1[m.queryIdx].pt for m in good_matches]).reshape(-1, 1, 2)
    dst_pts = np.float32([kp2[m.trainIdx].pt for m in good_matches]).reshape(-1, 1, 2)

    homography, _ = cv2.findHomography(src_pts, dst_pts, cv2.RANSAC, 5.0)
    if homography is None:
        raise RuntimeError("Homography estimation failed.")

    h, w = reference_gray.shape[:2]
    return cv2.warpPerspective(scan_gray, homography, (w, h))


# --------------------------------------------------------------------------
# Stage: ROI cropping
# --------------------------------------------------------------------------

def crop_field_rois(aligned_image: np.ndarray) -> dict[str, np.ndarray]:
    """Slice out each field's zone-of-interest (tight crop, not the full
    oversized input box) from an already-aligned image.
    """
    crops = {}
    h, w = aligned_image.shape[:2]
    pad = cfg.CROP_PADDING_PX

    for field_name, field_def in cfg.FIELDS.items():
        roi_pt = cfg.get_roi_pt(field_def)
        x1, y1, x2, y2 = cfg.pt_to_px(roi_pt)

        x1, y1 = max(0, x1 - pad), max(0, y1 - pad)
        x2, y2 = min(w, x2 + pad), min(h, y2 + pad)

        crops[field_name] = aligned_image[y1:y2, x1:x2]

    return crops


# --------------------------------------------------------------------------
# Stage: CRNN + CTC inference
# --------------------------------------------------------------------------

class CRNN(nn.Module):
    """PLACEHOLDER architecture. Must match what p2_epoch19_acc49.1.pth
    was actually trained with -- replace this body with the exact class
    from your training notebooks, or state_dict loading will fail with a
    shape mismatch.
    """

    def __init__(self, num_classes: int, img_height: int = 32):
        super().__init__()
        self.cnn = nn.Sequential(
            nn.Conv2d(1, 64, 3, 1, 1), nn.ReLU(), nn.MaxPool2d(2, 2),
            nn.Conv2d(64, 128, 3, 1, 1), nn.ReLU(), nn.MaxPool2d(2, 2),
            nn.Conv2d(128, 256, 3, 1, 1), nn.ReLU(),
            nn.Conv2d(256, 256, 3, 1, 1), nn.ReLU(), nn.MaxPool2d((2, 1), (2, 1)),
            nn.Conv2d(256, 512, 3, 1, 1), nn.BatchNorm2d(512), nn.ReLU(),
            nn.Conv2d(512, 512, 3, 1, 1), nn.BatchNorm2d(512), nn.ReLU(),
            nn.MaxPool2d((2, 1), (2, 1)),
            nn.Conv2d(512, 512, 2, 1, 0), nn.ReLU(),
        )
        self.rnn = nn.LSTM(512, 256, bidirectional=True, num_layers=2, batch_first=True)
        self.fc = nn.Linear(512, num_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        conv = self.cnn(x)
        conv = conv.squeeze(2)
        conv = conv.permute(0, 2, 1)
        recurrent, _ = self.rnn(conv)
        output = self.fc(recurrent)
        return output.permute(1, 0, 2)


@dataclass
class CRNNRecognizer:
    model_path: str
    char_list_path: str
    img_height: int = 32
    img_width: int = 128
    device: str = "cpu"

    def __post_init__(self):
        self.chars = self._load_char_list(self.char_list_path)
        self.idx_to_char = {i + 1: c for i, c in enumerate(self.chars)}  # 0 = CTC blank
        num_classes = len(self.chars) + 1

        self.model = CRNN(num_classes=num_classes, img_height=self.img_height)
        state_dict = torch.load(self.model_path, map_location=self.device)
        self.model.load_state_dict(state_dict)
        self.model.to(self.device)
        self.model.eval()

    @staticmethod
    def _load_char_list(path: str) -> list[str]:
        p = Path(path)
        if not p.exists():
            raise FileNotFoundError(
                f"Character list not found at {path}. Export the exact "
                "charset (and order) used during CRNN training."
            )
        with p.open(encoding="utf-8") as f:
            return [line.rstrip("\n") for line in f if line.strip()]

    def _preprocess_crop(self, crop: np.ndarray) -> torch.Tensor:
        if crop.size == 0:
            raise ValueError("Empty crop passed to recognizer -- check ROI coordinates.")
        resized = cv2.resize(crop, (self.img_width, self.img_height))
        normalized = resized.astype(np.float32) / 255.0
        tensor = torch.from_numpy(normalized).unsqueeze(0).unsqueeze(0)
        return tensor.to(self.device)

    def _ctc_greedy_decode(self, logits: torch.Tensor) -> str:
        probs = logits.softmax(2)
        preds = probs.argmax(2).squeeze(1).tolist()

        chars, prev = [], None
        for idx in preds:
            if idx != 0 and idx != prev:
                chars.append(self.idx_to_char.get(idx, ""))
            prev = idx
        return "".join(chars)

    def predict(self, crop: np.ndarray) -> str:
        with torch.no_grad():
            tensor = self._preprocess_crop(crop)
            logits = self.model(tensor)
            return self._ctc_greedy_decode(logits)


# --------------------------------------------------------------------------
# Full pipeline orchestration
# --------------------------------------------------------------------------

class OCRPipeline:
    def __init__(
        self,
        model_path: str,
        char_list_path: str,
        template_pdf_path: str | None = None,
        device: str = "cpu",
    ):
        pdf_path = template_pdf_path or cfg.REFERENCE_TEMPLATE_PATH
        self.reference_gray = self._load_reference(pdf_path)
        self.recognizer = CRNNRecognizer(
            model_path=model_path,
            char_list_path=char_list_path,
            device=device,
        )

    @staticmethod
    def _load_reference(pdf_path: str) -> np.ndarray:
        p = Path(pdf_path)
        if not p.exists():
            raise FileNotFoundError(
                f"Reference template PDF not found at {p}. Update "
                "template_config.REFERENCE_TEMPLATE_PATH or pass "
                "template_pdf_path explicitly."
            )
        return render_reference_template(str(p))

    def run(self, image_path: str) -> dict[str, str]:
        logger.info("Preprocessing scan: %s", image_path)
        scan_gray = load_and_preprocess(image_path)

        logger.info("Aligning scan to reference template")
        aligned = align_to_template(scan_gray, self.reference_gray)

        logger.info("Cropping %d field ROIs", len(cfg.FIELDS))
        crops = crop_field_rois(aligned)

        results: dict[str, str] = {}
        for field_name, crop in crops.items():
            try:
                text = self.recognizer.predict(crop)
            except Exception as e:  # noqa: BLE001
                logger.warning("Field '%s' failed OCR: %s", field_name, e)
                text = ""
            results[field_name] = text
            logger.info("  %-20s -> %r", field_name, text)

        return results

    def run_to_json(self, image_path: str, output_path: str | None = None) -> str:
        result = self.run(image_path)
        payload = json.dumps(result, ensure_ascii=False, indent=2)
        if output_path:
            Path(output_path).write_text(payload, encoding="utf-8")
            logger.info("Wrote output to %s", output_path)
        return payload


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Run the Nepali OCR pipeline on a scanned form.")
    parser.add_argument("image", help="Path to the scanned/filled document image")
    parser.add_argument("--model", required=True, help="Path to CRNN .pth checkpoint")
    parser.add_argument("--charlist", required=True, help="Path to character list text file")
    parser.add_argument("--template-pdf", default=None, help="Path to the clean template PDF")
    parser.add_argument("--output", default=None, help="Optional path to write JSON output")
    args = parser.parse_args()

    pipeline = OCRPipeline(
        model_path=args.model,
        char_list_path=args.charlist,
        template_pdf_path=args.template_pdf,
    )
    print(pipeline.run_to_json(args.image, args.output))
